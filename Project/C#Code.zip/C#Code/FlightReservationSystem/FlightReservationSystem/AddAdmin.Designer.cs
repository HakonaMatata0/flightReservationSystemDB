﻿namespace FlightReservationSystem
{
    partial class AddAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textEMAIL = new System.Windows.Forms.TextBox();
            this.textLNAME = new System.Windows.Forms.TextBox();
            this.textMNAME = new System.Windows.Forms.TextBox();
            this.textFNAME = new System.Windows.Forms.TextBox();
            this.textADMINID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ADD = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textEMAIL
            // 
            this.textEMAIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEMAIL.Location = new System.Drawing.Point(314, 338);
            this.textEMAIL.Margin = new System.Windows.Forms.Padding(4);
            this.textEMAIL.Name = "textEMAIL";
            this.textEMAIL.Size = new System.Drawing.Size(541, 45);
            this.textEMAIL.TabIndex = 28;
            // 
            // textLNAME
            // 
            this.textLNAME.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textLNAME.Location = new System.Drawing.Point(314, 278);
            this.textLNAME.Margin = new System.Windows.Forms.Padding(4);
            this.textLNAME.Name = "textLNAME";
            this.textLNAME.Size = new System.Drawing.Size(541, 45);
            this.textLNAME.TabIndex = 27;
            // 
            // textMNAME
            // 
            this.textMNAME.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMNAME.Location = new System.Drawing.Point(314, 205);
            this.textMNAME.Margin = new System.Windows.Forms.Padding(4);
            this.textMNAME.Name = "textMNAME";
            this.textMNAME.Size = new System.Drawing.Size(541, 45);
            this.textMNAME.TabIndex = 26;
            // 
            // textFNAME
            // 
            this.textFNAME.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFNAME.Location = new System.Drawing.Point(314, 145);
            this.textFNAME.Margin = new System.Windows.Forms.Padding(4);
            this.textFNAME.Name = "textFNAME";
            this.textFNAME.Size = new System.Drawing.Size(541, 45);
            this.textFNAME.TabIndex = 25;
            // 
            // textADMINID
            // 
            this.textADMINID.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textADMINID.Location = new System.Drawing.Point(314, 78);
            this.textADMINID.Margin = new System.Windows.Forms.Padding(4);
            this.textADMINID.Name = "textADMINID";
            this.textADMINID.Size = new System.Drawing.Size(541, 45);
            this.textADMINID.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 338);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 39);
            this.label5.TabIndex = 23;
            this.label5.Text = "EMAIL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 268);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 39);
            this.label4.TabIndex = 22;
            this.label4.Text = "LNAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 205);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 39);
            this.label3.TabIndex = 21;
            this.label3.Text = "MNAME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 145);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 39);
            this.label2.TabIndex = 20;
            this.label2.Text = "FNAME";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 78);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 39);
            this.label1.TabIndex = 19;
            this.label1.Text = "ADMIN_ID";
            // 
            // ADD
            // 
            this.ADD.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ADD.Location = new System.Drawing.Point(490, 468);
            this.ADD.Margin = new System.Windows.Forms.Padding(4);
            this.ADD.Name = "ADD";
            this.ADD.Size = new System.Drawing.Size(193, 47);
            this.ADD.TabIndex = 18;
            this.ADD.Text = "ADD";
            this.ADD.UseVisualStyleBackColor = true;
            this.ADD.Click += new System.EventHandler(this.ADD_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(524, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(184, 39);
            this.label6.TabIndex = 31;
            this.label6.Text = "Add Admin";
            // 
            // AddAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1273, 649);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textEMAIL);
            this.Controls.Add(this.textLNAME);
            this.Controls.Add(this.textMNAME);
            this.Controls.Add(this.textFNAME);
            this.Controls.Add(this.textADMINID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ADD);
            this.Name = "AddAdmin";
            this.Text = "AddAdmin";
            this.Load += new System.EventHandler(this.AddAdmin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textEMAIL;
        private System.Windows.Forms.TextBox textLNAME;
        private System.Windows.Forms.TextBox textMNAME;
        private System.Windows.Forms.TextBox textFNAME;
        private System.Windows.Forms.TextBox textADMINID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ADD;
        private System.Windows.Forms.Label label6;
    }
}